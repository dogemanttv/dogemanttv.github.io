import Cocoa
import MediaPlayer // Still needed for MPMediaItemArtwork if we get it
import AVFoundation // Import AVFoundation for media file metadata

@main
class AppDelegate: NSObject, NSApplicationDelegate {

    var statusBarItem: NSStatusItem!
    var marqueeView: MarqueeView!

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        let fixedMenuBarItemWidth: CGFloat = 200.0
        statusBarItem = NSStatusBar.system.statusItem(withLength: fixedMenuBarItemWidth)

        if let button = statusBarItem.button {
            marqueeView = MarqueeView(frame: button.bounds)
            button.addSubview(marqueeView)
        }
        
        // Observe distributed notifications for now playing info
        DistributedNotificationCenter.default.addObserver(self, selector: #selector(updateMarqueeFromDistributedNotification), name: Notification.Name("com.apple.iTunes.playerInfo"), object: nil)
        DistributedNotificationCenter.default.addObserver(self, selector: #selector(updateMarqueeFromDistributedNotification), name: Notification.Name("com.spotify.client.PlaybackStateChanged"), object: nil)

        // Initial update (will show "Music not playing" until a notification comes in)
        updateMarqueeFromDistributedNotification(nil)
    }

    @objc func updateMarqueeFromDistributedNotification(_ notification: Notification?) {
        var image: NSImage? = nil
        var artist = ""
        var album = ""
        var title = ""
        var fullText = "Music not playing"
        
        if let userInfo = notification?.userInfo {
            // Handle iTunes/Music.app notification
            if notification?.name == Notification.Name("com.apple.iTunes.playerInfo") {
                if let playerState = userInfo["Player State"] as? String, playerState == "Playing" {
                    artist = (userInfo["Artist"] as? String) ?? "Unknown Artist"
                    album = (userInfo["Album"] as? String) ?? "Unknown Album"
                    title = (userInfo["Name"] as? String) ?? "Unknown Song"
                    
                    fullText = "\(title) - \(album) - \(artist)" // Changed order
                    
                    // Attempt to get artwork from local Music library, passing target size
                    image = findArtworkInMusicLibrary(artist: artist, album: album, title: title, targetSize: marqueeView.bounds.height)
                    
                } else {
                    fullText = "Music not playing"
                }
            }
            // Handle Spotify notification
            else if notification?.name == Notification.Name("com.spotify.client.PlaybackStateChanged") {
                if let playerState = userInfo["PlayerState"] as? String, playerState == "Playing" {
                    artist = (userInfo["Artist"] as? String) ?? "Unknown Artist"
                    album = (userInfo["Album"] as? String) ?? "Unknown Album"
                    title = (userInfo["Name"] as? String) ?? "Unknown Song"
                    
                    fullText = "\(title) - \(album) - \(artist)" // Changed order
                    
                    // For Spotify, we still use a placeholder as local lookup is for Music.app files
                } else {
                    fullText = "Music not playing"
                }
            }
        }
        
        // If no artwork was obtained, use a default symbol
        if image == nil {
            image = NSImage(systemSymbolName: "music.note", accessibilityDescription: "Music Note")
        }

        marqueeView.update(with: image, text: fullText)
    }

    // MARK: - Local Artwork Lookup

    private func findArtworkInMusicLibrary(artist: String, album: String, title: String, targetSize: CGFloat) -> NSImage? {
        print("Attempting to find artwork in local Music library...")
        let fileManager = FileManager.default
        
        // Common Music library paths
        let musicLibraryPaths = [
            URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Music").appendingPathComponent("Media.localized").appendingPathComponent("Music"),
            URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Music").appendingPathComponent("iTunes").appendingPathComponent("iTunes Media").appendingPathComponent("Music"),
            URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Music").appendingPathComponent("Music"), // Direct Music folder
        ]
        
        for libraryPath in musicLibraryPaths {
            guard fileManager.fileExists(atPath: libraryPath.path) else {
                print("Music library path not found: \(libraryPath.path)")
                continue
            }
            
            print("Searching in: \(libraryPath.path)")
            
            // Enumerate contents of the music library
            if let enumerator = fileManager.enumerator(at: libraryPath, includingPropertiesForKeys: [.isRegularFileKey], options: [.skipsHiddenFiles, .skipsPackageDescendants]) {
                for case let fileURL as URL in enumerator {
                    // Only consider common audio file extensions
                    if ["mp3", "m4a", "aac", "flac", "wav"].contains(fileURL.pathExtension.lowercased()) {
                        // print("Checking file: \(fileURL.lastPathComponent)")
                        if let artwork = extractArtwork(from: fileURL, artist: artist, album: album, title: title, targetSize: targetSize) {
                            print("Artwork found for \(title) in \(fileURL.lastPathComponent)")
                            return artwork
                        }
                    }
                }
            }
        }
        
        print("No matching artwork found in local Music library.")
        return nil
    }

    private func extractArtwork(from fileURL: URL, artist: String, album: String, title: String, targetSize: CGFloat) -> NSImage? {
        let asset = AVAsset(url: fileURL)
        
        // Load metadata asynchronously to avoid blocking UI
        let commonMetadata = asset.commonMetadata
        
        var fileArtist: String? = nil
        var fileAlbum: String? = nil
        var fileTitle: String? = nil
        var fileArtwork: NSImage? = nil
        
        for item in commonMetadata {
            if item.commonKey == .commonKeyArtist {
                fileArtist = item.stringValue
            } else if item.commonKey == .commonKeyAlbumName {
                fileAlbum = item.stringValue
            } else if item.commonKey == .commonKeyTitle {
                fileTitle = item.stringValue
            } else if item.commonKey == .commonKeyArtwork {
                if let data = item.dataValue {
                    if let originalImage = NSImage(data: data) {
                        // Resize the image to the target size
                        let targetNSSize = NSSize(width: targetSize, height: targetSize)
                        let resizedImage = NSImage(size: targetNSSize)
                        resizedImage.lockFocus()
                        originalImage.draw(in: NSRect(origin: .zero, size: targetNSSize),
                                           from: NSRect(origin: .zero, size: originalImage.size),
                                           operation: .copy,
                                           fraction: 1.0)
                        resizedImage.unlockFocus()
                        fileArtwork = resizedImage
                    }
                }
            }
        }
        
        // Basic matching logic: all three must match
        if let fa = fileArtist, let fal = fileAlbum, let ft = fileTitle,
           fa.lowercased() == artist.lowercased() &&
           fal.lowercased() == album.lowercased() &&
           ft.lowercased() == title.lowercased() {
            
            return fileArtwork
        }
        
        return nil
    }
}
 
