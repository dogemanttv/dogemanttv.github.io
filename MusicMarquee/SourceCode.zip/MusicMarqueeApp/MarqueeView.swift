import Cocoa

class MarqueeView: NSView {

    private var contentView: NSView! // Container for the scrolling content
    private var imageView1: NSImageView! // First instance of image
    private var textField1: NSTextField! // First instance of text
    private var imageView2: NSImageView! // Second instance of image (for seamless loop)
    private var textField2: NSTextField! // Second instance of text
    
    private var lastText: String = ""

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        
        wantsLayer = true // Essential for animations
        layer?.masksToBounds = true // Clip content that goes outside bounds

        // Create the content view that will scroll
        contentView = NSView()
        contentView.wantsLayer = true
        addSubview(contentView)

        // First set of content
        imageView1 = NSImageView()
        imageView1.imageScaling = .scaleProportionallyUpOrDown
        contentView.addSubview(imageView1)

        textField1 = NSTextField(labelWithString: "")
        textField1.font = NSFont.menuBarFont(ofSize: 0)
        textField1.backgroundColor = .clear
        textField1.isBezeled = false
        contentView.addSubview(textField1)

        // Second set of content (for seamless looping)
        imageView2 = NSImageView()
        imageView2.imageScaling = .scaleProportionallyUpOrDown
        contentView.addSubview(imageView2)

        textField2 = NSTextField(labelWithString: "")
        textField2.font = NSFont.menuBarFont(ofSize: 0)
        textField2.backgroundColor = .clear
        textField2.isBezeled = false
        contentView.addSubview(textField2)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func update(with image: NSImage?, text: String) {
        // Only update if the text has actually changed to prevent animation restarts
        guard text != lastText else {
            return
        }
        lastText = text

        imageView1.image = image
        textField1.stringValue = text
        textField1.sizeToFit()

        imageView2.image = image
        textField2.stringValue = text
        textField2.sizeToFit()
        
        // Calculate sizes and positions
        let imageWidth = self.bounds.height // Square image
        let spacing: CGFloat = 4.0
        let textWidth = textField1.frame.width // Both text fields have same width
        let singleContentWidth = imageWidth + spacing + textWidth

        // Position first set of content
        imageView1.frame = NSRect(x: 0, y: 0, width: imageWidth, height: imageWidth)
        textField1.frame.origin = NSPoint(x: imageWidth + spacing, y: (self.bounds.height - textField1.frame.height) / 2)
        
        // Position second set of content immediately after the first, with a much larger gap
        let gapBetweenCopies: CGFloat = 135.0 // Increased gap
        imageView2.frame = NSRect(x: singleContentWidth + gapBetweenCopies, y: 0, width: imageWidth, height: imageWidth)
        textField2.frame.origin = NSPoint(x: singleContentWidth + gapBetweenCopies + imageWidth + spacing, y: (self.bounds.height - textField2.frame.height) / 2)

        // Set contentView frame to encompass both sets of content
        let totalScrollableWidth = singleContentWidth * 2 + gapBetweenCopies
        contentView.frame = NSRect(x: 0, y: 0, width: totalScrollableWidth, height: self.bounds.height)

        // Determine if animation is needed
        if singleContentWidth > self.bounds.width {
            startAnimation(singleContentWidth: singleContentWidth, gapBetweenCopies: gapBetweenCopies)
        } else {
            stopAnimation()
            // If no animation, ensure content is positioned at the start
            contentView.frame.origin.x = 0
        }
    }
    
    private func startAnimation(singleContentWidth: CGFloat, gapBetweenCopies: CGFloat) {
        contentView.layer?.removeAllAnimations()

        let visibleWidth = self.bounds.width
        
        // If content fits, no need to scroll
        guard singleContentWidth > visibleWidth else {
            contentView.frame.origin.x = 0 // Ensure it's at the start
            return
        }

        let marqueeSpeed: CGFloat = 37.0 // points per second

        // The total distance the content needs to travel for one full, seamless cycle.
        // It scrolls its own width plus the gap, then resets.
        let distanceToScroll = singleContentWidth + gapBetweenCopies

        let animation = CABasicAnimation(keyPath: "transform.translation.x")

        animation.fromValue = 0 // Start at no horizontal translation
        animation.toValue = -distanceToScroll // Translate left by the full scroll distance
        
        // Duration = distance / speed
        animation.duration = Double(distanceToScroll / marqueeSpeed)
        
        animation.repeatCount = .infinity
        animation.autoreverses = false
        animation.timingFunction = CAMediaTimingFunction(name: .linear)

        contentView.layer?.add(animation, forKey: "marqueeAnimation")
    }

    private func stopAnimation() {
        contentView.layer?.removeAnimation(forKey: "marqueeAnimation")
        // Reset the content view's position to its initial state
        contentView.frame.origin.x = 0
    }
}