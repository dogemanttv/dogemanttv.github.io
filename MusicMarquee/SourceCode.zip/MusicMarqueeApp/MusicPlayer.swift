
import Cocoa
import ScriptingBridge

// Protocols for Music.app scripting interface
// These protocols DO NOT inherit from SBApplication or SBObject.
// Instead, we will make SBApplication and SBObject conform to them via extensions.

@objc protocol MusicApplication {
    @objc dynamic optional var currentTrack: MusicTrack { get }
    @objc dynamic var isRunning: Bool { get }
}

@objc protocol MusicTrack {
    @objc dynamic optional var name: String { get }
    @objc dynamic optional var artist: String { get }
    @objc dynamic optional var album: String { get }
    @objc dynamic optional func artworks() -> SBElementArray
}

@objc protocol MusicArtwork {
    @objc dynamic optional var data: NSImage { get }
}

// Extend the generic ScriptingBridge classes to conform to our specific protocols.
// This allows us to cast SBApplication and SBObject instances to our more specific types.
extension SBApplication: MusicApplication {}
extension SBObject: MusicTrack, MusicArtwork {}
