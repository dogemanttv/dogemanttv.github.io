//
//  MusicMarqueeAppTests.swift
//  MusicMarqueeAppTests
//
//  Created by Logan on 7/13/25.
//

import Testing
@testable import MusicMarqueeApp

struct MusicMarqueeAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
